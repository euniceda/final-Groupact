<!DOCTYPE html>
<html>
<head>
    <title>New Laravel</title>
</head>
<body>
    <h1>Welcome to Laravel Application</h1>
</body>
</html>