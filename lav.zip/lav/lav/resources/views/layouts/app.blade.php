@extends('layouts.master')
@section('Title','INDEX')

@section('section')
		<h1>The quick brown fox jumps over the lazy dog</h1>
@endsection
@section('footer')
	Advance Web Development
@endsection